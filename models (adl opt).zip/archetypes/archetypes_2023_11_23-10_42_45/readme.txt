These are archetypes exported from the Clinical Knowledge Manager.
Export time: Thu Nov 23 10:42:45 CET 2023